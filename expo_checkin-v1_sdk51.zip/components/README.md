# Components

Place shared UI components here. Prefer co-locating styles and tests alongside implementation files.
