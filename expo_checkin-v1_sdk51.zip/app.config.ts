import { ConfigContext, ExpoConfig } from 'expo/config';
import 'dotenv/config';

export default ({ config }: ConfigContext): ExpoConfig => {
  const existingExtra = (config.extra ?? {}) as Record<string, unknown>;

  const supabaseUrl =
    process.env.EXPO_PUBLIC_SUPABASE_URL ??
    (existingExtra.supabaseUrl as string | undefined) ??
    '';

  const supabaseAnonKey =
    process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ??
    (existingExtra.supabaseAnonKey as string | undefined) ??
    '';

  const mergedConfig: ExpoConfig = {
    ...config,
    name: config.name ?? 'Expo Checkin',
    slug: config.slug ?? 'expo-checkin',
    extra: {
      ...existingExtra,
      supabaseUrl,
      supabaseAnonKey
    }
  };

  return mergedConfig;
};
