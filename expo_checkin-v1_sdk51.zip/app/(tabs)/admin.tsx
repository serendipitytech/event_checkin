import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';

import ActionButton from '../../components/ActionButton';
import {
  importAttendeesFromFile,
  resetAllCheckins,
  syncFromGoogleSheet
} from '../../services/attendees';

export default function AdminScreen() {
  const handleResetAll = () => {
    Alert.alert(
      'Reset All Check-Ins',
      'This will move every attendee back to Pending. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            try {
              await resetAllCheckins();
              Alert.alert('Reset complete', 'All attendees were marked Pending.');
            } catch (err) {
              Alert.alert('Unable to reset', 'Check your connection and try again.');
            }
          }
        }
      ]
    );
  };

  const handleImportRoster = () => {
    Alert.alert(
      'Roster Import',
      'File import for CSV/XLSX will live here. Decide on the preferred mobile picker workflow before enabling this action.'
    );
    importAttendeesFromFile('FILE_URI_PLACEHOLDER');
  };

  const handleSyncSheet = () => {
    Alert.alert(
      'Google Sheet Sync',
      'Google Sheet sync will route through the proxy once implemented.'
    );
    syncFromGoogleSheet('GOOGLE_SHEET_URL_PLACEHOLDER');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>Admin Tools</Text>
      <Text style={styles.description}>
        Manage roster imports, Google Sheet syncs, and bulk actions from this
        screen. Confirm the preferred import UX before wiring the remaining
        flows.
      </Text>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Bulk Actions</Text>
        <Text style={styles.cardSubtitle}>
          Use these tools to reset the roster or reload data sources.
        </Text>
        <View style={styles.actions}>
          <ActionButton
            label="Import CSV/XLSX"
            variant="secondary"
            onPress={handleImportRoster}
          />
          <ActionButton
            label="Sync Google Sheet"
            variant="secondary"
            onPress={handleSyncSheet}
          />
          <ActionButton
            label="Reset Check-Ins"
            variant="danger"
            onPress={handleResetAll}
          />
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Next Steps</Text>
        <Text style={styles.cardSubtitle}>
          - Integrate a file/document picker for roster uploads.
          {'\n'}- Confirm Google Sheet proxy usage and authentication.
          {'\n'}- Mirror additional admin toggles from the web UI (auto refresh,
          compact stats, etc.).
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 24,
    gap: 24,
    backgroundColor: '#f4f5f7'
  },
  heading: {
    fontSize: 26,
    fontWeight: '700',
    color: '#1f1f1f'
  },
  description: {
    fontSize: 16,
    color: '#4a4a4a',
    lineHeight: 22
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    gap: 16,
    shadowColor: '#000000',
    shadowOpacity: 0.08,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 6 },
    elevation: 3
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1f1f1f'
  },
  cardSubtitle: {
    fontSize: 14,
    color: '#555555',
    lineHeight: 20
  },
  actions: {
    gap: 12
  }
});
